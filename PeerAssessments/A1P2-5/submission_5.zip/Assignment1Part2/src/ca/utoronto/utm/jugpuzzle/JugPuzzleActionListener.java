package ca.utoronto.utm.jugpuzzle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;

public class JugPuzzleActionListener implements ActionListener
{
		private JTextField t;
		JugPuzzleActionListener(JTextField t) 
		{
			this.t=t;
		}
		
		public void actionPerformed(ActionEvent e) 
		{
			
		}
		
}
